package cc.ccwu.betier;


import cc.ccwu.betier.api.ApiClient;
import cc.ccwu.betier.command.TierCommand;
import cc.ccwu.betier.event.PlayerJoinEvent;
import cc.ccwu.betier.event.ServerStartEvent;
import cc.ccwu.betier.network.BeTierNetworking;


import net.fabricmc.api.ModInitializer;


import org.slf4j.Logger;
import org.slf4j.LoggerFactory;



public class BeTierMod implements ModInitializer {


    public static final String MOD_ID = "betier";


    public static final Logger LOGGER =
            LoggerFactory.getLogger(MOD_ID);



    @Override
    public void onInitialize() {


        LOGGER.info("==============================");
        LOGGER.info(" BeTier 1.21.11 Loaded ");
        LOGGER.info("==============================");



        // 注册服务器到客户端的数据通道
        BeTierNetworking.register();



        // 保存服务器实例，用于同步在线玩家
        ServerStartEvent.register();



        // 加载 Tier API 数据
        ApiClient.update();



        // 注册 /tier 命令
        TierCommand.register();



        // 注册玩家加入事件
        PlayerJoinEvent.register();



        LOGGER.info("BeTier initialization complete.");

    }


}