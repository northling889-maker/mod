package cc.ccwu.betier.client;


public class ClientTierData {


    public static String sword = "-";

    public static String crystal = "-";

    public static String uhc = "-";

    public static String axe = "-";


    public static void update(
            String sword,
            String crystal,
            String uhc,
            String axe
    ){

        ClientTierData.sword = sword;
        ClientTierData.crystal = crystal;
        ClientTierData.uhc = uhc;
        ClientTierData.axe = axe;

    }


}