package cc.ccwu.betier.client;


import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.text.Text;



public class TierHud {


    public static void register() {


        HudRenderCallback.EVENT.register(
                (drawContext, tickDelta) -> {

                    render(drawContext);

                }
        );


    }



    private static void render(
            DrawContext context
    ) {


        MinecraftClient client =
                MinecraftClient.getInstance();



        if(client.player == null) {

            return;

        }



        int x = 10;
        int y = 10;



        context.drawText(

                client.textRenderer,

                Text.literal("BeTier"),

                x,

                y,

                0xFFFFFF,

                true

        );



        context.drawText(

                client.textRenderer,

                Text.literal(
                        "Sword: "
                        + ClientTierData.sword
                ),

                x,

                y + 15,

                0x55FFFF,

                false

        );



        context.drawText(

                client.textRenderer,

                Text.literal(
                        "Axe: "
                        + ClientTierData.axe
                ),

                x,

                y + 30,

                0x55FF55,

                false

        );



        context.drawText(

                client.textRenderer,

                Text.literal(
                        "Crystal: "
                        + ClientTierData.crystal
                ),

                x,

                y + 45,

                0xFF55FF,

                false

        );



        context.drawText(

                client.textRenderer,

                Text.literal(
                        "UHC: "
                        + ClientTierData.uhc
                ),

                x,

                y + 60,

                0xFFFF55,

                false

        );


    }


}