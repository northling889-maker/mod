package cc.ccwu.betier.client;


import cc.ccwu.betier.network.ClientPayloadHandler;


import net.fabricmc.api.ClientModInitializer;



public class BeTierClient implements ClientModInitializer {


    @Override
    public void onInitializeClient() {


        ClientPayloadHandler.register();


        TierHud.register();


    }


}