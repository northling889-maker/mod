package cc.ccwu.betier.model;


public class TierProfile {

    public int id;

    public String name;

    public String Sword;
    public String Axe;
    public String SMP;
    public String UHC;
    public String Crystal;
    public String Mace;

    public String Pot;
    public String NethPot;
    public String OPot;
    public String OUHC;

    public String Bedwars;
    public String Fireball;

    public String TopFight;
    public String Archer;
    public String Sumo;
    public String Boxing;


    public String create_time;


    public TierProfile() {

    }


    public String getName(){

        return name;

    }

}