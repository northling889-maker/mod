package cc.ccwu.betier.cache;


import cc.ccwu.betier.model.TierProfile;

import java.util.HashMap;
import java.util.Map;



public class TierCache {


    private static final Map<String, TierProfile> CACHE =
            new HashMap<>();



    public static void put(TierProfile profile){

        CACHE.put(
                profile.name.toLowerCase(),
                profile
        );

    }



    public static TierProfile get(String name){

        return CACHE.get(
                name.toLowerCase()
        );

    }



    public static int size(){

        return CACHE.size();

    }



    public static void clear(){

        CACHE.clear();

    }


}