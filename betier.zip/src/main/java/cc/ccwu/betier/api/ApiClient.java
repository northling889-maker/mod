package cc.ccwu.betier.api;


import cc.ccwu.betier.cache.TierCache;
import cc.ccwu.betier.model.TierProfile;
import cc.ccwu.betier.network.BeTierSync;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;


import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;

import java.util.List;



public class ApiClient {


    private static final String URL =
            "https://betierapi.ccwu.cc/api/all";



    public static void update(){


        Thread.startVirtualThread(() -> {


            try {


                HttpClient client =
                        HttpClient.newHttpClient();



                HttpRequest request =
                        HttpRequest.newBuilder()

                                .uri(URI.create(URL))

                                .GET()

                                .build();



                HttpResponse<String> response =
                        client.send(

                                request,

                                HttpResponse.BodyHandlers.ofString()

                        );



                List<TierProfile> list =
                        new Gson().fromJson(

                                response.body(),

                                new TypeToken<List<TierProfile>>() {}

                                        .getType()

                        );



                TierCache.clear();



                for(TierProfile profile : list){


                    TierCache.put(profile);


                }



                System.out.println(

                        "[BeTier] Loaded "

                        + TierCache.size()

                        + " players"

                );



                // API加载完成后同步在线玩家
                BeTierSync.syncAll();



            }
            catch(Exception e){


                System.err.println(
                        "[BeTier] API Error"
                );


                e.printStackTrace();


            }



        });


    }


}