package cc.ccwu.betier.event;


import cc.ccwu.betier.cache.TierCache;
import cc.ccwu.betier.model.TierProfile;
import cc.ccwu.betier.network.TierPayload;


import net.fabricmc.fabric.api.networking.v1.ServerPlayConnectionEvents;
import net.fabricmc.fabric.api.networking.v1.ServerPlayNetworking;


import net.minecraft.server.network.ServerPlayerEntity;
import net.minecraft.text.Text;



public class PlayerJoinEvent {


    public static void register() {


        ServerPlayConnectionEvents.JOIN.register(
                (handler, sender, server) -> {


                    ServerPlayerEntity player =
                            handler.getPlayer();


                    String name =
                            player.getName()
                                    .getString();



                    TierProfile profile =
                            TierCache.get(name);



                    if(profile != null) {


                        // 发送 Tier 数据到客户端
                        ServerPlayNetworking.send(
                                player,
                                new TierPayload(
                                        profile.Sword,
                                        profile.Crystal,
                                        profile.UHC,
                                        profile.Axe
                                )
                        );



                        // 登录提示
                        player.sendMessage(

                                Text.literal(
                                        "§6[BeTier]\n"
                                        +
                                        "§fYour Tier loaded."
                                ),

                                false

                        );


                    } else {


                        player.sendMessage(

                                Text.literal(
                                        "§6[BeTier] §7No tier data found."
                                ),

                                false

                        );


                    }


                }
        );


    }


}