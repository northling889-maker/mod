package cc.ccwu.betier.command;


import cc.ccwu.betier.cache.TierCache;
import cc.ccwu.betier.model.TierProfile;

import com.mojang.brigadier.arguments.StringArgumentType;

import net.fabricmc.fabric.api.command.v2.CommandRegistrationCallback;

import net.minecraft.server.command.CommandManager;
import net.minecraft.text.Text;



public class TierCommand {


    public static void register(){


        CommandRegistrationCallback.EVENT.register(
                (dispatcher, registryAccess, environment) -> {


                    dispatcher.register(

                        CommandManager.literal("tier")

                        .then(
                            CommandManager.argument(
                                    "player",
                                    StringArgumentType.word()
                            )

                            .executes(context -> {


                                String name =
                                        StringArgumentType.getString(
                                                context,
                                                "player"
                                        );


                                TierProfile profile =
                                        TierCache.get(name);



                                if(profile == null){


                                    context.getSource()
                                            .sendFeedback(
                                                    () -> Text.literal(
                                                            "§c没有找到玩家: "
                                                            + name
                                                    ),
                                                    false
                                            );


                                    return 1;

                                }



                                context.getSource()
                                        .sendFeedback(
                                                () -> Text.literal(
                                                        createMessage(profile)
                                                ),
                                                false
                                        );


                                return 1;


                            })
                        )

                    );

                }
        );


    }



    private static String createMessage(
            TierProfile p
    ){


        return
                "§6===== BeTier =====\n"

                + "§fPlayer: §a"
                + p.name
                + "\n\n"

                + "§fSword: §b"
                + p.Sword
                + "\n"

                + "§fAxe: §b"
                + p.Axe
                + "\n"

                + "§fCrystal: §b"
                + p.Crystal
                + "\n"

                + "§fUHC: §b"
                + p.UHC
                + "\n"

                + "§fMace: §b"
                + p.Mace

                + "\n§6==================";

    }

}