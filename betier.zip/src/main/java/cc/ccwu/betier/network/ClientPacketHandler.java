package cc.ccwu.betier.network;


import cc.ccwu.betier.client.ClientTierData;


import net.fabricmc.fabric.api.client.networking.v1.ClientPlayNetworking;



public class ClientPayloadHandler {


    public static void register(){


        ClientPlayNetworking.registerGlobalReceiver(
                TierPayload.ID,
                (payload, context) -> {


                    context.client()
                            .execute(() -> {


                                ClientTierData.update(

                                        payload.sword(),

                                        payload.crystal(),

                                        payload.uhc(),

                                        payload.axe()

                                );


                            });


                }
        );


    }


}