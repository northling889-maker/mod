package cc.ccwu.betier.network;


import net.fabricmc.fabric.api.networking.v1.PayloadTypeRegistry;



public class BeTierNetworking {


    public static void register(){


        PayloadTypeRegistry.playS2C()
                .register(
                        TierPayload.ID,
                        TierPayload.CODEC
                );


    }


}