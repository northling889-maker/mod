package cc.ccwu.betier.network;


import net.minecraft.network.RegistryByteBuf;
import net.minecraft.network.codec.PacketCodec;
import net.minecraft.network.packet.CustomPayload;
import net.minecraft.util.Identifier;



public record TierPayload(
        String sword,
        String crystal,
        String uhc,
        String axe
) implements CustomPayload {



    public static final Id<TierPayload> ID =
            new Id<>(
                    Identifier.of(
                            "betier",
                            "tier"
                    )
            );



    public static final PacketCodec<RegistryByteBuf, TierPayload> CODEC =
            PacketCodec.of(
                    (value, buf) -> {

                        buf.writeString(value.sword());
                        buf.writeString(value.crystal());
                        buf.writeString(value.uhc());
                        buf.writeString(value.axe());

                    },

                    buf -> new TierPayload(

                            buf.readString(),
                            buf.readString(),
                            buf.readString(),
                            buf.readString()

                    )
            );



    @Override
    public Id<? extends CustomPayload> getId() {

        return ID;

    }

}