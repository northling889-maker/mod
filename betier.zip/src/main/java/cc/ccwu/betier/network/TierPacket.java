package cc.ccwu.betier.network;


import net.minecraft.network.PacketByteBuf;


public class TierPacket {


    private final String sword;
    private final String crystal;
    private final String uhc;
    private final String axe;



    public TierPacket(
            String sword,
            String crystal,
            String uhc,
            String axe
    ){

        this.sword = sword;
        this.crystal = crystal;
        this.uhc = uhc;
        this.axe = axe;

    }



    public String sword(){

        return sword;

    }


    public String crystal(){

        return crystal;

    }


    public String uhc(){

        return uhc;

    }


    public String axe(){

        return axe;

    }


}